import os


os.mkdir('Módulo 4'+os.sep+'Arquivos')
os.makedirs('Módulo 4'+os.sep+'Arquivos'+os.sep+'Arquivos pdf')
os.makedirs('Módulo 4'+os.sep+'Fotos'+os.sep+'Fotos Verão')
